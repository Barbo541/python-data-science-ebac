# Módulo 7: Módulo 7
Este notebook contém os exercícios do módulo 7 do curso **Python para Ciência de Dados** da EBAC.

## Conteúdo
- Resumo será atualizado com base no conteúdo do notebook.

## Instruções
1. Execute as células na ordem apresentada.
2. Certifique-se de que os arquivos necessários estão na pasta `data/`.
